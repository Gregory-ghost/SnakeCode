<?php

const COMMAND = [
    'CHANGE_DIRECTION' => 'changeDirection' // изменить направление змеи
    'CREATE_SNAKE' => 'createSnake', // добавить змею
    'DESTROY_SNAKE' => 'destroySnake', // убрать змею
    'UPDATE_SCENE' => 'updateSnake', // обновить сцену/получить данные
];