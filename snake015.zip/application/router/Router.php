<?php

class Router {
		public function answer($options) {
			return $options;
			
		}

}