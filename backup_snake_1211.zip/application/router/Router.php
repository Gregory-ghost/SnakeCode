<?php

require_once dirname(__DIR__).'/game/Game.php';
require_once dirname(__DIR__) . '/modules/db/db.php';
require_once dirname(__DIR__) . '/modules/user/User.php';

class Router {

    private $db;
    private $user;
	private $game;

	public function __construct() {
        $this->db = new DB();
        $options = new stdClass();
        // Получение из Базы данных
        $options->maps = $this->db->getMaps();
        $options->foods = $this->db->getFoods();
        $options->snakes = $this->db->getSnakes();
        $options->users = $this->db->getUsers();
        $options->snakesBody = $this->db->getSnakesBody();
		$this->game = new Game($options);
		$this->user = new User($this->db);
	}

	// Хороший ответ, возвращаем данные
	private function good($text) {
	    return [
	        'result' => true,
            'data' => $text,
        ];
    }

    // Плохой ответ, возвращаем ошибку
    private function bad($text) {
	    return [
	        'result' => false,
            'error' => $text,
	        ];
    }
	
	public function answer($options) {
	    if ( $options and isset($options->method) ) {
	        $method = $options->method;
            if ( $method ) {
                switch ($method) {
                    case 'login':
                        $result = $this->user->login($options->login, $options->password);
                        return ($result) ? $this->good($result) : $this->bad('authorization fail');
                        break;
                    case 'logout':
                        $result = $this->user->logout($options->token);
                        return ($result) ? $this->good($result) : $this->bad('logout fail');
                        break;
                    //...
                }
                $userId = $this->user->checkToken($options->token);
                if ($userId) {
                    $COMMAND = $this->game->getCommand();
                    foreach ( $COMMAND as $command ) {
                        if ( $command === $method ) {
                            unset($options->method);
                            $result = $this->game->executeCommand($method, $options);
                            return ($result) ?
                                $this->good($this->game->getStruct()) :
                                $this->bad('method wrong execute');
                        }
                    }
                }
                return $this->bad('Invalid token');
            } else {
                return $this->bad('The method ' . $method . ' has no exist');
            }
        }
		return $this->bad('You must set method param');
	}
}