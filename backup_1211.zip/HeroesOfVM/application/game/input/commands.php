<?php

const COMMAND = [
    PASS_ITEM_HEROES => 'passItemHeroes',
    GET_ELEM_BY_ID => 'getElemById',
    GET_GAMER => 'getGamer',
    GET_STRUCT => 'getStruct', // получить данные с сервера
    END_TURN => 'endTurn', // конец хода игрока
    ADD_ARTIFACT_TO_BACKPACK => 'addArtifactToBackpack',
    PASS_UNIT => 'passUnit',

    MOVE_HERO => 'moveHero' // подвинуть героя
    //...
];