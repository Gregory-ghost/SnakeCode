<?php

require_once 'Unit.php';

class del {
    public $units;

    public function __construct() {
        $this->units = [null, null, null, null, null, null, null];
    }
}