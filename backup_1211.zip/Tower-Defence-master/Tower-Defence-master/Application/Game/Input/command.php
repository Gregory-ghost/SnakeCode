<?php

const COMMAND = [
    'ROTATE_TOWER' => 'rotateTower',        // повернуть башню
    'SHOTING'      => 'shoting',            // выстрелить
    'MOVE_MOB'     => 'moveMob',            // подвинуть моба
    'ADD_TOWER'    => 'addTower',           // добавить башню
    'ADD_MOB'      => 'addMob',             // добавить моба
    'DEL_TOWER'    => 'delTower',           // удалить башню
    'KILL_MOB'     => 'killMob'             // удалить моба
];