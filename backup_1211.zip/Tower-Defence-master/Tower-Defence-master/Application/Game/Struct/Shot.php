<?php

require_once "Unit.php";

class Shot extends Unit {
    public function __construct($options) {
        parent::__construct($options);
    }
}
