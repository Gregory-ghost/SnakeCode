<?php
// Список основных команд для обращения api

const COMMAND = [
    'CHANGE_DIRECTION' => 'changeDirection', // изменить направление змеи
    'GET_SCENE' => 'getScene', // получить информацию о сцене
];